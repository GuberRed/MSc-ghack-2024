rm ghackcfinit.zip
zip -r ghackcfinit.zip .