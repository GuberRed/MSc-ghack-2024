rm ghackcf.zip
zip -r ghackcf.zip .