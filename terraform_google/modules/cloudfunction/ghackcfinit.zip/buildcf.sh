rm ../terraform_google/modules/cloudfunction/ghackcfinit.zip
zip -r ghackcfinit.zip .
mv ghackcfinit.zip ../terraform_google/modules/cloudfunction